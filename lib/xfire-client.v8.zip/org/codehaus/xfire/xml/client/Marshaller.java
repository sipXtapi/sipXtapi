package org.codehaus.xfire.xml.client;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

/**
 * transform a Object to a Soap XML Request Document
 */
public class Marshaller {

    /**
     * Add for each param of the method the data to the dom tree element
     * 
     * @param parameterTypes
     * @param params
     * @param writer
     * @param namespaceMethod
     * @throws IOException
     * @throws IllegalArgumentException
     * @throws SecurityException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws IntrospectionException
     * @throws NoSuchFieldException
     * @throws ClassNotFoundException
     * @throws XMLStreamException 
     */
    public static void transform(Class[] parameterTypes, Object[] params,XMLStreamWriter writer, 
            final String namespaceMethod) throws IOException, IllegalArgumentException,
            SecurityException, IllegalAccessException, InvocationTargetException, IntrospectionException,
            NoSuchFieldException, ClassNotFoundException, XMLStreamException {
        // create empty namespace holder
        Map map = new HashMap();
        int counter = 0;
        for (int i = 0; i < params.length; i++) {
            Object param = params[i];
            Class clazz = parameterTypes[i];            
            writer.writeStartElement(SoapInvocator.METHOD_NAMESPACE_PREFIX,"in"+i,namespaceMethod);
            if (clazz.isArray()) {
                Class arrayClass = clazz.getComponentType();
                if (arrayClass.equals(String.class) || arrayClass.equals(Integer.class)
                        || arrayClass.equals(Integer.TYPE) || arrayClass.equals(Long.class)
                        || arrayClass.equals(Long.TYPE) || arrayClass.equals(Short.class)
                        || arrayClass.equals(Short.TYPE) || arrayClass.equals(Byte.class)
                        || arrayClass.equals(Byte.TYPE) || arrayClass.equals(Boolean.class)
                        || arrayClass.equals(Boolean.TYPE) || arrayClass.equals(Double.class)
                        || arrayClass.equals(Double.TYPE) || arrayClass.equals(Float.class)
                        || arrayClass.equals(Float.TYPE)) {
                    String className = null;
                    if (arrayClass.getName().indexOf(".") > -1) {
                        className = arrayClass.getName().substring(arrayClass.getName().lastIndexOf(".") + 1,
                                arrayClass.getName().length()).toLowerCase();
                    }
                    else {
                        className = arrayClass.getName();
                    }
                    if (param != null) {
                        int countChilds = Array.getLength(param);
                        for (int n = 0; n < countChilds; n++) {
                            writer.writeStartElement(SoapInvocator.METHOD_NAMESPACE_PREFIX,className,namespaceMethod);
                            Object val = Array.get(param, n);
                            writer.writeCharacters(val.toString());
                            writer.writeEndElement();
                        }
                    }
                    else {
                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                    }
                }

                else {
                    addFieldElements(writer, arrayClass, param, null,null, map, counter);
                }
            }
            else if (clazz.equals(String.class) || clazz.equals(Integer.class)
                    || clazz.equals(Integer.TYPE) || clazz.equals(Long.class)
                    || clazz.equals(Long.TYPE) || clazz.equals(Short.class)
                    || clazz.equals(Short.TYPE) || clazz.equals(Byte.class)
                    || clazz.equals(Byte.TYPE) || clazz.equals(Boolean.class)
                    || clazz.equals(Boolean.TYPE) || clazz.equals(Double.class)
                    || clazz.equals(Double.TYPE) || clazz.equals(Float.class)
                    || clazz.equals(Float.TYPE) || clazz.equals(BigDecimal.class)) {
                if (param != null) {
                    writer.writeCharacters(param.toString());
                }
                else {
                    writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                }
            }
            else if(clazz.equals(Date.class)||clazz.equals(java.sql.Date.class)||clazz.equals(Timestamp.class)){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                writer.writeCharacters(format.format((Date)param));
            }
            else {
                addFieldElements(writer, clazz, param, null,null,  map, counter);
            }
            writer.writeEndElement();
        }
    }

    /**
     * Add for each attribute content to object element in dom tree
     * 
     * @param root
     * @param methodElement
     * @param clazz
     * @param obj
     * @param nameSpace
     * @param map
     * @param counter
     * @throws IllegalArgumentException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws IntrospectionException
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws XMLStreamException 
     */
    private static void addFieldElements(XMLStreamWriter writer, Class clazz, Object obj,
            String nameSpace,String prefix, Map map, int counter) throws IllegalArgumentException,
            IllegalAccessException, InvocationTargetException, IntrospectionException, SecurityException,
            NoSuchFieldException, XMLStreamException {
        if (nameSpace == null) {
            String ns = createNamespaceFromPackageName(clazz.getPackage().getName());
            // cache namespaces
            if (map.containsKey(ns)) {
                prefix = (String) map.get(ns);
                writer.writeNamespace(prefix,ns);
            }
            else {
                counter++;
                prefix = "ns" + counter;
                map.put(ns, prefix);
                nameSpace = ns;
                writer.writeNamespace(prefix,ns);
            }
        }
        // try to use get/set methods to get values
        BeanInfo info = Introspector.getBeanInfo(clazz);
        PropertyDescriptor[] props = info.getPropertyDescriptors();
        for (int i = 0; i < props.length; i++) {
            PropertyDescriptor prop = props[i];
            if (!prop.getName().equalsIgnoreCase("class")) {
                Class type = prop.getPropertyType();
                Method meth = prop.getReadMethod();

                Object val = null;
                String propertyName = prop.getName();
                writer.writeStartElement(prefix,propertyName,nameSpace);
                if (meth != null) {
                    
                    if (obj != null) {
                        val = meth.invoke(obj, null);
                    }
                    else {
                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                        writer.writeEndElement();
                        continue;
                    }
                }
                else {
                    // ok hard way
                    if (obj != null) {
                        Field field = clazz.getField(propertyName);
                        field.setAccessible(true);
                        String name = field.getName();
                        val = field.get(obj);
                    }
                    else {
                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                        writer.writeEndElement();
                        continue;
                    }
                }
                // directly set values if type is not a object
                if (type == String.class || type == Integer.class || type == Long.class|| type == Date.class || type == Float.TYPE
                        || type == Timestamp.class || type == Double.TYPE || type == Long.TYPE || type == Integer.TYPE
                        || type == Short.class || type == Byte.class || type == Double.class || type == Float.class
                        || type == BigDecimal.class || type == Boolean.TYPE || type == Integer.TYPE) {
                    if (val != null) {
                        writer.writeCharacters(val.toString());
                    }
                    else {
                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                    }
                }
                else {
                    if (val == null) {
                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                    }
                    else {
                        if (type.isArray()) {
                            if (type.getComponentType().equals(String.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"string",nameSpace);
                                    String arrValue = (String) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue);
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Integer.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"integer",nameSpace);
                                    Integer arrValue = (Integer) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Integer.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"integer",nameSpace);
                                    int arrValue = Array.getInt(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Long.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"long",nameSpace);
                                    long arrValue = Array.getLong(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Long.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"Long",nameSpace);
                                    Long arrValue = (Long) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Double.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"double",nameSpace);
                                    double arrValue = Array.getDouble(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Double.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"Double",nameSpace);
                                    Double arrValue = (Double) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Float.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"float",nameSpace);
                                    float arrValue = Array.getFloat(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Float.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"Float",nameSpace);
                                    Float arrValue = (Float) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Byte.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"byte",nameSpace);
                                    byte arrValue = Array.getByte(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Byte.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"Byte",nameSpace);
                                    Byte arrValue = (Byte) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Short.TYPE)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"short",nameSpace);
                                    short arrValue = Array.getShort(val, n);
                                    writer.writeCharacters(arrValue+"");
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(Short.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"Short",nameSpace);
                                    Short arrValue = (Short) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else if (type.getComponentType().equals(BigDecimal.class)) {
                                int length = Array.getLength(val);
                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefix,"decimal",nameSpace);
                                    BigDecimal arrValue = (BigDecimal) Array.get(val, n);
                                    if (arrValue != null) {
                                        writer.writeCharacters(arrValue.toString());
                                    }
                                    else {
                                        writer.writeAttribute(SoapInvocator.SCHEMA_NAMESPACE_PREFIX,SoapInvocator.SCHEMA_NS,"nil","true");
                                    }
                                    writer.writeEndElement();
                                }
                            }
                            else {
                                int length = Array.getLength(val);
                                Class clazzArrayElement = type.getComponentType();
                                String clazzArrayName = clazzArrayElement.getName();
                                String namespaceArrayElement = createNamespaceFromPackageName(clazzArrayElement
                                        .getPackage().getName());
                                String prefixArrayElement = null;
                                // cache namespaces
                                if (map.containsKey(namespaceArrayElement)) {
                                    prefixArrayElement = (String) map.get(namespaceArrayElement);
                                }
                                else {
                                    counter++;
                                    prefixArrayElement = "ns" + counter;
                                    writer.writeNamespace(prefixArrayElement,namespaceArrayElement);
                                }

                                for (int n = 0; n < length; n++) {
                                    writer.writeStartElement(prefixArrayElement,clazzArrayName.substring(clazzArrayName.lastIndexOf(".") + 1),namespaceArrayElement);
                                    addFieldElements(writer,clazzArrayElement, Array.get(val, n),
                                            namespaceArrayElement, prefixArrayElement,  map, counter);
                                    writer.writeEndElement();
                                }

                            }
                        }
                        else {
                            addFieldElements(writer, type, val, null, null, map, counter);
                        }
                    }

                }
                writer.writeEndElement();
            }
        }
    }

    /**
     * make from class with package a.b.c an namespace like http://c.b.a
     * 
     * @param pckg
     * @return
     */
    private final static String createNamespaceFromPackageName(String pckg) {
        StringBuffer buf = new StringBuffer("http://");
        List list = new Vector();
        StringTokenizer token = new StringTokenizer(pckg, ".");
        while (token.hasMoreTokens()) {
            list.add(token.nextToken());
        }
        String[] arr = new String[list.size()];
        list.toArray(arr);
        for (int n = arr.length - 1; n > -1; n--) {
            buf.append(arr[n]);
            if (n != 0) {
                buf.append(".");
            }
        }
        return buf.toString();
    }

}
