package org.codehaus.xfire.xml.client;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.xfire.xml.client.config.ConfigData;
import org.codehaus.xfire.xml.client.config.ConfigReader;



/**
 * Factory to create Soap clients stubs
 */
public class SoapInvocatorFactory {
    private final static String SOAP_12_NS = "http://www.w3.org/2003/05/soap-envelope";
    private final static String SOAP_11_NS = "http://schemas.xmlsoap.org/soap/envelope/";
    private final static String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema-instance";
    private final static SoapInvocatorFactory instance = new SoapInvocatorFactory();
    private ConfigReader reader = ConfigReader.getInstance();
    private Log log = LogFactory.getLog(SoapInvocatorFactory.class); 
    
    private SoapInvocatorFactory() {
        // singleton
    }
    
    /**
     * Create a proxy Stub to enable dynamic soap calls where the base URL 
     * is defined in the config file
     * 
     * @param serviceClass class or interface of the service
     * @return Stub
     * @throws Exception
     * @see ConfigReader#CONFIG_FILE_NAME
     */
    public static Object createStub(Class serviceClass) throws Exception{
		Object obj = !(serviceClass.isInterface())?serviceClass.newInstance():serviceClass;
					
        String nameSpace = instance.getNameSpace(serviceClass);
        String targetURL = instance.getTargetURL(serviceClass,null);
        String soapNS = instance.getSoapNameSpace(serviceClass);
        boolean isInternalExceptionsThrown = instance.isInternalExceptionsThrown();
        return SoapInvocator.newInstance(obj,nameSpace,targetURL,soapNS,SCHEMA_NS,isInternalExceptionsThrown);
    }
    
    /**
     * Create a proxy Stub to enable dynamic soap calls
     * 
     * @param serviceClass class or interface of the service
     * @param baseURL base URL of the soap endpoint like http://localhost:8080/XFireTest/services/, if null use config value
     * @return
     * @throws Exception
     */
    public static Object createStub(Class serviceClass,String baseURL) throws Exception{
        Object obj = !(serviceClass.isInterface())?serviceClass.newInstance():serviceClass;
                    
        String nameSpace = instance.getNameSpace(serviceClass);
        String targetURL = instance.getTargetURL(serviceClass,baseURL);
        String soapNS = instance.getSoapNameSpace(serviceClass);
        boolean isInternalExceptionsThrown = instance.isInternalExceptionsThrown();
        return SoapInvocator.newInstance(obj,nameSpace,targetURL,soapNS,SCHEMA_NS,isInternalExceptionsThrown);
    }    
    
    private boolean isInternalExceptionsThrown(){
        return reader.isThrowInternalExceptions();
    }
    
    /**
     * get namespace for service class 
     * 
     * @param serviceClass
     * @return
     */
    private String getNameSpace(Class serviceClass) {
        ConfigData data = reader.getServiceConfig(serviceClass);
        if(data!=null) {
            String nameSpace = data.getUrn();
            if(log.isTraceEnabled()) {
                log.trace("NS is "+nameSpace+" for "+serviceClass.getName());
            }
            return nameSpace;
        }
        else {
            // log only once if no cfg is found 
            if(log.isFatalEnabled()){
                log.fatal("No config section for service "+serviceClass.getName()+" in file "+ConfigReader.CONFIG_FILE_NAME);
            }
        }        
        return null;
    }
    
    /**
     * get soap version (1.1 or 1.2) for service
     * 
     * @param serviceClass
     * @return
     */
    private String getSoapNameSpace(Class serviceClass) {
        ConfigData data = reader.getServiceConfig(serviceClass);
        if(data!=null) {
            String soapVersion = data.getSoapVersion();
            if(log.isTraceEnabled()) {
                log.trace("soap version is "+soapVersion+" for "+serviceClass.getName());
            }
            if(soapVersion.equalsIgnoreCase("1.2")) {
                return SOAP_12_NS;
            }
            else if(soapVersion.equalsIgnoreCase("1.1")) {
                return SOAP_11_NS;
            } 
        }
        return null;
    }
    
    /**
     * build up url like http://localhost:8080/XFireTest/services/ProductService
     * for specific service
     * 
     * @param serviceClass service to build url for
     * @param baseURL if null use config file value
     * @return service url
     */
    private String getTargetURL(Class serviceClass,String baseURL) {
        ConfigData data = reader.getServiceConfig(serviceClass);
        if(data!=null) {
            String serviceName = data.getServiceName();
            String configBaseURL = reader.getBaseURL();
            String url = null;
            if(baseURL!=null && baseURL.trim().length()>0) {
                if(!baseURL.trim().endsWith("/")) {
                    serviceName = "/" + serviceName;
                }
                url = baseURL.trim()+serviceName;                
            }
            else {
                if(!configBaseURL.trim().endsWith("/")) {
                    serviceName = "/" + serviceName;
                }
                url = configBaseURL.trim()+serviceName;                   
            }
            if(log.isTraceEnabled()) {
                log.trace("URL is "+url+" for "+serviceClass.getName());
            }
            return url;
        }       
        return null;
    }
}
