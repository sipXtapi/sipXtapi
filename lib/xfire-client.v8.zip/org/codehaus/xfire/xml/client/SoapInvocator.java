package org.codehaus.xfire.xml.client;

import java.beans.IntrospectionException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.MalformedURLException;
import java.net.ProtocolException;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpVersion;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * invoke the soap service
 */
public final class SoapInvocator implements InvocationHandler {

    public static final String SOAP_NAMESPACE_PREFIX = "soap";

    public static final String METHOD_NAMESPACE_PREFIX = "tns";

    public static final String SCHEMA_NAMESPACE_PREFIX = "xsi";

    public final static String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";

    private Object obj;

    private String nameSpace;

    private String targetURL;

    private String schemaNS;

    private String soapNS;

    private boolean throwInternalExceptions = false;

    private Log log = LogFactory.getLog(SoapInvocator.class);

    public static Object newInstance(Object obj, String nameSpace, String targetURL, String soapNS, String schemaNS,
            boolean throwInternalExceptions) {

        Class classObj = null;
        Class[] interfaces = null;
        if (obj instanceof Class) {
            classObj = (Class) obj;
        }
        else {
            classObj = obj.getClass();
        }
        if (classObj.isInterface()) {
            interfaces = new Class[] { classObj };
        }
        else {
            interfaces = classObj.getInterfaces();
        }
        if (interfaces == null || interfaces.length == 0) {
            throw new IllegalArgumentException("Class " + classObj.getName() + " does not implement a interface!");
        }
        return Proxy.newProxyInstance(classObj.getClassLoader(), interfaces, new SoapInvocator(obj, nameSpace,
                targetURL, soapNS, schemaNS, throwInternalExceptions));
    }

    private SoapInvocator(Object obj, String nameSpace, String targetURL, String soapNS, String schemaNS,
            boolean throwInternalExceptions) {
        this.obj = obj;
        this.nameSpace = nameSpace;
        this.targetURL = targetURL;
        this.soapNS = soapNS;
        this.schemaNS = schemaNS;
        this.throwInternalExceptions = throwInternalExceptions;
    }

    /**
     * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
     */
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        Object obj = null;
        try {
            if (log.isTraceEnabled()) {
                log.trace("invoke method " + method.getName() + " from Object " + this.obj.toString());
            }

            if (method.getName().equals("toString")) {
                return "not available";
            }

            // create http client
            HttpClient client = new HttpClient();
            client.getParams().setParameter("http.protocol.version", HttpVersion.HTTP_1_1);
            client.getParams().setParameter("http.socket.timeout", new Integer(1000));
            client.getParams().setParameter("http.protocol.content-charset", "UTF-8");
            PostMethod postMethod = new PostMethod(this.targetURL);

            // Create an output factory
            XMLOutputFactory xmlof = XMLOutputFactory.newInstance();
            // Create an XML stream writer
            StringWriter stringWriter = new StringWriter();
            XMLStreamWriter xmlw = xmlof.createXMLStreamWriter(stringWriter);

            // create request doc
            xmlw.writeStartElement(SOAP_NAMESPACE_PREFIX, "Envelope", soapNS);
            xmlw.writeDefaultNamespace(soapNS);
            xmlw.writeNamespace(SCHEMA_NAMESPACE_PREFIX, schemaNS);
            xmlw.writeNamespace(SOAP_NAMESPACE_PREFIX, soapNS);
            xmlw.writeNamespace(METHOD_NAMESPACE_PREFIX, nameSpace);
            xmlw.writeEmptyElement(SOAP_NAMESPACE_PREFIX, "Header", soapNS);
            xmlw.writeStartElement(SOAP_NAMESPACE_PREFIX, "Body", soapNS);
            xmlw.writeStartElement(METHOD_NAMESPACE_PREFIX, method.getName(), nameSpace);
            if (args != null) {
                Marshaller.transform(method.getParameterTypes(), args, xmlw, nameSpace);
            }
            xmlw.writeEndElement(); // end method inside body
            xmlw.writeEndElement(); // end body
            xmlw.writeEndDocument(); // end doc

            // write xml output into a string
            xmlw.flush();
            xmlw.close();
            stringWriter.flush();
            stringWriter.close();
            String request = stringWriter.getBuffer().toString().trim();

            // set correct soap header
            postMethod.setRequestHeader("Content-Length", request.length() + "");
            postMethod.setRequestHeader("Content-Type", "text/xml; charset=UTF-8");
            postMethod.setRequestHeader("SOAPAction", "");
            if (log.isTraceEnabled()) {
                log.trace("REQUEST:\n" + request.toString());
            }
            // set soap body
            postMethod.setRequestEntity(new StringRequestEntity(request));
            // send soap message
            client.executeMethod(postMethod);
            // Get response data.
            BufferedReader reader = new BufferedReader(new InputStreamReader(postMethod.getResponseBodyAsStream()));
            // analyse response object from method
            Class returnType = method.getReturnType();
            Class[] exceptionTypes = method.getExceptionTypes();
            // transform soap message into object
            obj = UnMarshaller.transform(returnType, exceptionTypes, reader);
            // cleanup http client
            postMethod.releaseConnection();
        }
        catch (IllegalArgumentException e) {
            log.error("Can't access fields", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (SecurityException e) {
            log.error("Can't access fields", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (MalformedURLException e) {
            log.error("Wrong URL " + this.targetURL, e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (ProtocolException e) {
            log.error("Communication Errors", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (IOException e) {
            log.error("Communication Errors", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (IllegalAccessException e) {
            log.error("Can't access fields", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (InvocationTargetException e) {
            if (e.getCause() != null) {
                log.error("Error invoking method", e.getCause());
                throw e.getCause();
            }
            else {
                log.error("Error invoking method", e);
                if (this.throwInternalExceptions) {
                    throw new SoapException(e);
                }
            }
        }
        catch (IntrospectionException e) {
            log.error("Can't access fields", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (NoSuchFieldException e) {
            log.error("Can't access fields", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        catch (InstantiationException e) {
            log.error("Can't instantiate objects", e);
            if (this.throwInternalExceptions) {
                throw new SoapException(e);
            }
        }
        return obj;
    }

}
