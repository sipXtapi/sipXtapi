package org.codehaus.xfire.xml.client;

/**
 * Exception to transport internal exceptions from the client api 
 */
public class SoapException extends Exception {

    public SoapException() {
    }

    public SoapException(String message) {
        super(message);
    }

    public SoapException(String message, Throwable cause) {
        super(message, cause);
    }

    public SoapException(Throwable cause) {
        super(cause);
    }

}
