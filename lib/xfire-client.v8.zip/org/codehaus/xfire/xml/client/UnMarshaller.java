package org.codehaus.xfire.xml.client;

import java.io.Reader;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.stream.XMLInputFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.yom.Document;
import org.codehaus.yom.Element;
import org.codehaus.yom.Elements;
import org.codehaus.yom.Text;
import org.codehaus.yom.stax.StaxBuilder;

/**
 * convert a xml document into java objects
 */
public final class UnMarshaller {

    private static final String DATE_PATTERN_LONG = "yyyy-MM-dd HH:mm:ss.SSSZ";
    private static final String DATE_PATTERN_SHORT = "yyyy-MM-dd HH:mm:ssZ";

    /**
     * transform xml response into new object setup by xml Element
     * 
     * @param returnType
     * @param exceptionTypes
     * @param xmlContent
     * @return
     * @throws Exception
     * @throws Exception
     */
    public final static Object transform(Class returnType, Class[] exceptionTypes, Reader xmlContent) throws Exception {

        Log log = LogFactory.getLog(UnMarshaller.class);

        XMLInputFactory factory = XMLInputFactory.newInstance();
        
        StaxBuilder builder = new StaxBuilder(factory);
        Document doc = builder.build(xmlContent);
        
        if(log.isTraceEnabled()){
            log.trace("Response:\n"+doc.toXML());
        }
        
        Element root = doc.getRootElement();
        Element body = (Element) root.getChildElements().get(0);
        // check void
        if (returnType.equals(Void.TYPE)) {
            checkFault(body, exceptionTypes);
            return null;
        }
        else {
            checkFault(body, exceptionTypes);
            Element responseElement = (Element) body.getChildElements().get(0);
            Elements attribElements = responseElement.getChildElements();
            // array?
            if (returnType.isArray()) {
                int countChilds = attribElements.get(0).getChildCount();
                // primitive types = [I
                if (returnType.getName().length() == 2) {
                    Class arrayClass = returnType.getComponentType();
                    Object arr = Array.newInstance(arrayClass, countChilds);
                    for (int i = 0; i < countChilds; i++) {
                        Element arrElement = (Element) attribElements.get(0).getChild(i);
                        if (arrayClass.equals(Integer.TYPE)) {
                            Array.setInt(arr, i, new Integer(arrElement.getValue()).intValue());
                        }
                        else if (arrayClass.equals(Long.TYPE)) {
                            Array.setLong(arr, i, new Long(arrElement.getValue()).longValue());
                        }
                        else if (arrayClass.equals(Short.TYPE)) {
                            Array.setShort(arr, i, new Short(arrElement.getValue()).shortValue());
                        }
                        else if (arrayClass.equals(Double.TYPE)) {
                            Array.setDouble(arr, i, new Double(arrElement.getValue()).doubleValue());
                        }
                        else if (arrayClass.equals(Float.TYPE)) {
                            Array.setFloat(arr, i, new Float(arrElement.getValue()).floatValue());
                        }
                        else if (arrayClass.equals(Byte.TYPE)) {
                            Array.setByte(arr, i, new Byte(arrElement.getValue()).byteValue());
                        }
                        else if (arrayClass.equals(Boolean.TYPE)) {
                            Array.setBoolean(arr, i, new Boolean(arrElement.getValue()).booleanValue());
                        }
                        else if (arrayClass.equals(Character.TYPE)) {
                            Array.setChar(arr, i, new Character(arrElement.getValue().charAt(0)).charValue());
                        }
                    }
                    return arr;
                }
                else {
                    String arrayClassName = returnType.getName().substring(2, returnType.getName().length() - 1);
                    Class arrayClass = Class.forName(arrayClassName);
                    Object arr = Array.newInstance(arrayClass, countChilds);
                    for (int i = 0; i < countChilds; i++) {
                        Element arrElement = (Element) attribElements.get(0).getChild(i);
                        if (arrayClass.equals(Integer.class) || arrayClass.equals(Long.class)
                                || arrayClass.equals(Double.class) || arrayClass.equals(String.class)
                                || arrayClass.equals(Float.class) || arrayClass.equals(Character.class)
                                || arrayClass.equals(Boolean.class) || arrayClass.equals(BigDecimal.class)
                                || arrayClass.equals(Short.class)) {
                            Constructor ctr = arrayClass.getConstructor(new Class[] { String.class });
                            Object value = ctr.newInstance(new Object[] { arrElement.getValue() });
                            Array.set(arr, i, value);
                        }
                        else if (arrayClass.equals(java.util.Date.class) || arrayClass.equals(java.sql.Date.class)) {
                            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            String val = arrElement.getValue();
                            val = val.replaceAll("T", " ");
                            val = val.substring(0,val.length()-6);
                            Date value = format.parse(val);
                            Array.set(arr, i, value);
                        }
                        else {
                            Object arrayObj = arrayClass.newInstance();
                            Array.set(arr, i, arrayObj);
                            Elements arrElementContent = arrElement.getChildElements();
                            for (int n = 0; n < arrElementContent.size(); n++) {
                                Element arrElementField = (Element) arrElementContent.get(n);
                                setField(arrElementField, arrayObj);
                            }
                        }
                    }
                    return arr;
                }
            }
            // primitive
            else if (returnType.equals(String.class)) {
                if (attribElements.size() > 0) {
                    Element attribElement = attribElements.get(0);
                    if(attribElement.getChildCount()>0){
                        return attribElement.getValue();                        
                    }
                    else {
                        return null;
                    }
                }
                else {
                    return null;
                }
            }
            else if (returnType.equals(Integer.class) || returnType.equals(Integer.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Integer(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Long.class) || returnType.equals(Long.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Long(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Short.class) || returnType.equals(Short.TYPE)) {
                Element attribElement =  attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Short(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Byte.class) || returnType.equals(Byte.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Byte(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Double.class) || returnType.equals(Double.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Double(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Float.class) || returnType.equals(Float.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Float(val.trim());
                }
                return null;
            }
            else if (returnType.equals(Boolean.class) || returnType.equals(Boolean.TYPE)) {
                Element attribElement = attribElements.get(0);
                String val = attribElement.getValue();
                if (val != null && val.trim().length() > 0) {
                    return new Boolean(val.trim());
                }
                return null;
            }
            // ok bean
            else {
                if (returnType.equals(Date.class)||returnType.equals(java.sql.Date.class)) {
                    // 2005-09-04T22:53:05+02:00
                    SimpleDateFormat format = new SimpleDateFormat();
                    Element attribElement = attribElements.get(0);
                    String val = attribElement.getValue();
                    if(val.indexOf(".")>0){
                        format.applyPattern(DATE_PATTERN_LONG);
                    }
                    else {
                        format.applyPattern(DATE_PATTERN_SHORT);
                    }
                    val = val.replaceAll("T", " ");
                    int pos = val.lastIndexOf(":");
                    val = val.substring(0,pos)+val.substring(pos+1);
                    Date date = format.parse(val);
                    GregorianCalendar cal = new GregorianCalendar();
                    cal.setTime(date);
                    int offSet = cal.getTimeZone().getOffset(date.getTime());
                    if(offSet>0){
                        cal.add(Calendar.MILLISECOND,-offSet);
                    }
                    else {
                        cal.add(Calendar.MILLISECOND,offSet);
                    }
                    return cal.getTime();
                }
                else if (returnType.equals(Timestamp.class)) {
                    // 2005-09-04T22:53:05+02:00
                    SimpleDateFormat format = new SimpleDateFormat();
                    Element attribElement = attribElements.get(0);
                    String val = attribElement.getValue();
                    if(val.indexOf(".")>0){
                        format.applyPattern(DATE_PATTERN_LONG);
                    }
                    else {
                        format.applyPattern(DATE_PATTERN_SHORT);
                    }
                    val = val.replaceAll("T", " ");
                    int pos = val.lastIndexOf(":");
                    val = val.substring(0,pos)+val.substring(pos+1);
                    Date date = format.parse(val);
                    GregorianCalendar cal = new GregorianCalendar();
                    cal.setTime(date);
                    int offSet = cal.getTimeZone().getOffset(date.getTime());
                    if(offSet>0){
                        cal.add(Calendar.MILLISECOND,-offSet);
                    }
                    else {
                        cal.add(Calendar.MILLISECOND,offSet);
                    }
                    return new Timestamp(cal.getTime().getTime());
                }
                else if (returnType.equals(Time.class)) {
                    return null;
                }
                else if (returnType.equals(BigDecimal.class)) {
                    Element attribElement = attribElements.get(0);
                    BigDecimal val = new BigDecimal(attribElement.getValue());
                    return val;
                }
                else {
                    Object obj = returnType.newInstance();
                    Element outElement = attribElements.get(0);
                    for (int i = 0; i < outElement.getChildCount(); i++) {
                        Element attribElement = (Element) outElement.getChild(i);
                        setField(attribElement, obj);
                    }
                    return obj;
                }
            }
        }
    }

    /**
     * see if their is a soap fault and throw the exception if necessary
     * 
     * @param body
     *            soap body
     * @param exceptionTypes
     *            exceptions thrown by the service method
     * @throws Exception
     *             throw the exception defined in the detail with guven soap reason text as message
     */
    private static void checkFault(Element body, Class[] exceptionTypes) throws Exception {
        Log log = LogFactory.getLog(UnMarshaller.class);
        if (body != null && !(body.getChildElements().size()==0)) {
            Element fault = (Element) body.getChildElements().get(0);
            if (fault.getLocalName().equals("Fault")) {
                if (fault.getNamespacePrefix() != null && fault.getNamespacePrefix().equals("soap")) {
                    Element reason = (Element) fault.getChild(1); // reason is
                    // second
                    // one
                    Element reasonText = (Element) reason.getChildElements().get(0);
                    Class exceptionClass = null;
                    if (fault.getChildCount() == 3) { // 0 code 1 reason 2
                        // detail
                        Element detail = (Element) fault.getChild(2);
                        Elements exceptionList = detail.getChildElements("exception");
                        if (exceptionList != null && exceptionList.size() > 0) {
                            Element detailText = (Element) exceptionList.get(0);
                            try {
                                exceptionClass = Class.forName(detailText.getValue());
                            }
                            catch (ClassNotFoundException e) {
                                log.error("Can't found exceptionclass " + detailText.getValue());
                            }
                        }
                    }
                    String message = reasonText.getValue();
                    if (exceptionTypes != null && exceptionTypes.length > 0) {
                        Exception ex = null;
                        if (exceptionClass != null) {
                            // throw only the exception defined in the detail
                            for (int n = 0; n < exceptionTypes.length; n++) {
                                if (exceptionTypes[n].equals(exceptionClass)) {
                                    ex = (Exception) exceptionTypes[n].getConstructor(new Class[] { String.class })
                                            .newInstance(new Object[] { message });
                                }
                            }
                        }
                        else {
                            // use first defined exception
                            ex = (Exception) exceptionTypes[0].getConstructor(new Class[] { String.class })
                                    .newInstance(new Object[] { message });
                        }
                        if (ex == null) {
                            // use first defined exception if defined detail
                            // exception class isn't found
                            log
                                    .error("exception class defined in the message isn't thrown by the local method! use first defined one");
                            ex = (Exception) exceptionTypes[0].getConstructor(new Class[] { String.class })
                                    .newInstance(new Object[] { message });
                        }
                        throw ex;
                    }
                    else {
                        // use standard exception
                        throw new Exception(message);
                    }
                }
            }
        }
    }

    private static void setField(Element attribElement, Object obj) throws ParseException {
        Log log = LogFactory.getLog(UnMarshaller.class);
        String attribName = attribElement.getLocalName();
        Class objectType = obj.getClass();
        try {
            Field field = objectType.getDeclaredField(attribName);
            field.setAccessible(true);
            Class fieldType = field.getType();
            if (fieldType.isArray()) {
                int countChilds = attribElement.getChildCount();
                Class arrayClass = fieldType.getComponentType();
                Object arr = Array.newInstance(arrayClass, countChilds);
                for (int i = 0; i < countChilds; i++) {
                    Element arrElement = (Element) attribElement.getChild(i);
                    Object arrayObj = null;
                    try {
                        arrayObj = arrayClass.newInstance();
                        Array.set(arr, i, arrayObj);
                    }
                    catch (InstantiationException iaex) {
                        arrayObj = arrayClass.getConstructor(new Class[] { String.class }).newInstance(
                                new Object[] { new String("0") });
                    }
                    for (int n = 0; n < arrElement.getChildCount(); n++) {
                        Object objArrElement = arrElement.getChild(n);
                        if (objArrElement instanceof Element) {
                            Element arrElementField = (Element) objArrElement;
                            setField(arrElementField, arrayObj);
                        }
                        else {
                            Text arrContentField = (Text) objArrElement;
                            Class objType = arrayObj.getClass();
                            String val = arrContentField.getValue();
                            if (objType.equals(String.class)) {
                                Array.set(arr, i, val);
                            }
                            else if (objType.equals(Integer.class) || objType.equals(Integer.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Integer(val.trim()));
                                }
                            }
                            else if (objType.equals(Long.class) || objType.equals(Long.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Long(val.trim()));
                                }
                            }
                            else if (objType.equals(Short.class) || objType.equals(Short.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Short(val.trim()));
                                }
                            }
                            else if (objType.equals(Byte.class) || objType.equals(Byte.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Byte(val.trim()));
                                }
                            }
                            else if (objType.equals(Double.class) || objType.equals(Double.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Double(val.trim()));
                                }
                            }
                            else if (objType.equals(Float.class) || objType.equals(Float.TYPE)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new Float(val.trim()));
                                }
                            }
                            else if (fieldType.equals(BigDecimal.class)) {
                                if (val != null && val.trim().length() > 0) {
                                    Array.set(arr, i, new BigDecimal(val.trim()));
                                }
                            }
                            else {
                                if (objType.equals(Date.class)) {
                                    // 2005-05-12T20:04:29.325Z
                                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                                    val = val.replaceAll("T", " ");
                                    val = val.replaceAll("Z", "");
                                    Date date = format.parse(val);
                                    Array.set(arr, i, date);
                                }
                            }

                        }
                    }
                }
                field.set(obj, arr);
            }
            else if (fieldType.isPrimitive()) {
                if (fieldType.equals(Double.TYPE)) {
                    double val = Double.parseDouble(attribElement.getValue());
                    field.setDouble(obj, val);
                }
                else if (fieldType.equals(Float.TYPE)) {
                    float val = Float.parseFloat(attribElement.getValue());
                    field.setFloat(obj, val);
                }
                else if (fieldType.equals(Integer.TYPE)) {
                    int val = Integer.parseInt(attribElement.getValue());
                    field.setInt(obj, val);
                }
                else if (fieldType.equals(Long.TYPE)) {
                    long val = Long.parseLong(attribElement.getValue());
                    field.setLong(obj, val);
                }
                else if (fieldType.equals(Byte.TYPE)) {
                    byte val = Byte.parseByte(attribElement.getValue());
                    field.setByte(obj, val);
                }
                else if (fieldType.equals(Short.TYPE)) {
                    short val = Short.parseShort(attribElement.getValue());
                    field.setShort(obj, val);
                }
                else if (fieldType.equals(Boolean.TYPE)) {
                    boolean val = Boolean.valueOf(attribElement.getValue()).booleanValue();
                    field.setBoolean(obj, val);
                }
                else if (fieldType.equals(Character.TYPE)) {
                    char val = attribElement.getValue().charAt(0);
                    field.setChar(obj, val);
                }
            }
            // object
            else {
                // don't set null values
                if (attribElement.getChildCount()==1 && !(attribElement.getChild(0) instanceof Element)) {
                    if (fieldType.equals(Integer.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Integer.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Double.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Double.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Short.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Short.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Float.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Float.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Long.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Long.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Boolean.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Boolean.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Byte.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = Byte.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(String.class)) {
                        Class[] paramTypes = { String.class };
                        Constructor ctr = String.class.getConstructor(paramTypes);
                        String[] paramVal = { attribElement.getValue() };
                        Object objField = ctr.newInstance(paramVal);
                        field.set(obj, objField);
                    }
                    else if (fieldType.equals(Date.class)) {
                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                        String val = attribElement.getValue();
                        val = val.replaceAll("T", " ");
                        val = val.replaceAll("Z", "");
                        Date date = format.parse(val);
                        field.set(obj, date);
                    }
                    else if (fieldType.equals(BigDecimal.class)) {
                        String val = attribElement.getValue();
                        BigDecimal bd = new BigDecimal(val);
                        field.set(obj, bd);
                    }
                }
                else {
                    if (fieldType.equals(Date.class)||fieldType.equals(java.sql.Date.class)||fieldType.equals(Timestamp.class)) {
                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                        String val = attribElement.getValue();
                        if(val!=null&&val.trim().length()>0){
                            val = val.replaceAll("T", " ");
                            val = val.replaceAll("Z", "");
                            Date date = format.parse(val);
                            field.set(obj, date);                            
                        }
                    }
                    else if (fieldType.equals(BigDecimal.class)) {
                        String val = attribElement.getValue();
                        if(val!=null&&val.trim().length()>0){
                            BigDecimal bd = new BigDecimal(val);
                            field.set(obj, bd);                            
                        }
                    }
                    else {
                        Object objField = fieldType.newInstance();
                        for (int n = 0; n < attribElement.getChildCount(); n++) {
                            setField((Element) attribElement.getChild(n), objField);
                        }
                        field.set(obj, objField);                        
                    }
                }
            }
        }
        catch (SecurityException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
        catch (NoSuchFieldException e) {
            log.error("Field " + attribName + " not exists in " + objectType.getName(), e);
        }
        catch (IllegalArgumentException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
        catch (IllegalAccessException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
        catch (InstantiationException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
        catch (NoSuchMethodException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
        catch (InvocationTargetException e) {
            log.error("Can't access Field " + attribName + " of " + objectType.getName(), e);
        }
    }

}
