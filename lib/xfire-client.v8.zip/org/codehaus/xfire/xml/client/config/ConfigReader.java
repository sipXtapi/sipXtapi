package org.codehaus.xfire.xml.client.config;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.yom.Document;
import org.codehaus.yom.Element;
import org.codehaus.yom.Elements;
import org.codehaus.yom.stax.StaxBuilder;

/**
 * Reader for the soap client configuration
 */
public class ConfigReader {
    /**
     * xfire-soapclient.xml
     */
    public final static String CONFIG_FILE_NAME = "xfire-soapclient.xml";

    private final static String NODE_NAME = "node";

    private final static String ENTY_NAME = "entry";

    private final static String NAME_ATTRIBUTE = "name";

    private final static String VALUE_ATTRIBUTE = "value";

    private final static String BASE_URL_NAME = "baseURL";
    
    private final static String THROW_INTERNAL_EXCEPTIONS_NAME = "throwInternalExceptions";

    private final static String SERVICE_NAME = "serviceName";

    private final static String URN_NAME = "urn";

    private final static String SOAP_VERSION = "soapVersion";

    private final static ConfigReader instance = new ConfigReader();

    private Map content = new HashMap();

    private String baseURL;

    private boolean throwInternalExceptions = false;
    
    private Log log = LogFactory.getLog(ConfigReader.class);

    private ConfigReader() {
        read();
    }

    /**
     * get singleton instance
     * 
     * @return
     */
    public static ConfigReader getInstance() {
        return instance;
    }

    /**
     * return Service definition or null if not found
     * 
     * @param serviceClass
     * @return
     */
    public ConfigData getServiceConfig(Class serviceClass) {

        if (content.containsKey(serviceClass.getName())) {
            return (ConfigData) content.get(serviceClass.getName());
        }
        log.error("Service " + serviceClass.getName() + " not found!");
        return null;
    }

    private void read() {

        // Build the JDOM Document
        InputStream in = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE_NAME);
        if (in != null) {
            try {
                XMLInputFactory ifactory = XMLInputFactory.newInstance();
                XMLStreamReader reader = ifactory.createXMLStreamReader(in);
                StaxBuilder builder = new StaxBuilder();
                Document doc = builder.build(reader);
                Element root = doc.getRootElement();

                Elements contents = root.getChildElements();
                for (int i = 0; i < contents.size(); i++) {
                    Element element = contents.get(i);
                    // first element must be base url entry
                    if (i == 0) {
                        if (element.getLocalName().equals(ENTY_NAME) && element.getAttribute(NAME_ATTRIBUTE) != null
                                && element.getAttributeValue(NAME_ATTRIBUTE).equalsIgnoreCase(BASE_URL_NAME)) {
                            this.baseURL = element.getAttributeValue(VALUE_ATTRIBUTE);
                        }
                        else {
                            log.error("First element must be entry element with name "+BASE_URL_NAME);
                        }
                    }
                    else if(i==1){
                        if (element.getLocalName().equals(ENTY_NAME) && element.getAttribute(NAME_ATTRIBUTE) != null
                                && element.getAttributeValue(NAME_ATTRIBUTE).equalsIgnoreCase(THROW_INTERNAL_EXCEPTIONS_NAME)) {
                            String value = element.getAttributeValue(VALUE_ATTRIBUTE);
                            if(value!=null && value.trim().length()>0 && value.trim().equalsIgnoreCase("true")){
                                this.throwInternalExceptions = true;
                            }
                        }
                        else {
                            log.error("Second element must be entry element with name "+THROW_INTERNAL_EXCEPTIONS_NAME);
                        }
                    }
                    else {
                        Elements services = element.getChildElements();
                        for (int n = 0; n < services.size(); n++) {
                            Element service = services.get(n);
                            String serviceClassname = service.getAttributeValue(NAME_ATTRIBUTE);
                            ConfigData data = new ConfigData();
                            Elements defs = service.getChildElements();
                            for (int m = 0; m < defs.size(); m++) {
                                Element def = defs.get(m);
                                if (def.getAttributeValue(NAME_ATTRIBUTE).equalsIgnoreCase(SOAP_VERSION)) {
                                    data.setSoapVersion(def.getAttributeValue(VALUE_ATTRIBUTE));
                                }
                                else if (def.getAttributeValue(NAME_ATTRIBUTE).equalsIgnoreCase(URN_NAME)) {
                                    data.setUrn(def.getAttributeValue(VALUE_ATTRIBUTE));
                                }
                                else if (def.getAttributeValue(NAME_ATTRIBUTE).equalsIgnoreCase(SERVICE_NAME)) {
                                    data.setServiceName(def.getAttributeValue(VALUE_ATTRIBUTE));
                                }
                            }
                            data.setServiceImplClassname(serviceClassname);
                            content.put(serviceClassname, data);
                        }
                    }
                }
            }
            catch (FactoryConfigurationError e) {
                log.error("Error with Stax factory",e);
            }
            catch (XMLStreamException e) {
                log.error("Error reading config file",e);
            }
        }
        else {
            log.fatal("Can't find Config file: " + CONFIG_FILE_NAME);
        }

    }

    /**
     * @return Returns the baseURL.
     */
    public String getBaseURL() {
        return baseURL;
    }

    public boolean isThrowInternalExceptions() {
        return this.throwInternalExceptions;
    }
}
