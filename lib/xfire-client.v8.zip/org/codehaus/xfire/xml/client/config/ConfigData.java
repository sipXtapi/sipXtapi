package org.codehaus.xfire.xml.client.config;

/**
 * soap client config data for a specific service
 */
public class ConfigData {
    private String serviceImplClassname;
    private String soapVersion;
    private String serviceName;
    private String urn;
    
    /**
     * constructor
     */
    public ConfigData() {
    }
    
    /**
     * @return Returns the serviceImplClassname.
     */
    public String getServiceImplClassname() {
        return serviceImplClassname;
    }
    /**
     * @param serviceImplClassname The serviceImplClassname to set.
     */
    public void setServiceImplClassname(String serviceImplClassname) {
        this.serviceImplClassname = serviceImplClassname;
    }
    /**
     * @return Returns the serviceName.
     */
    public String getServiceName() {
        return serviceName;
    }
    /**
     * @param serviceName The serviceName to set.
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    /**
     * @return Returns the soapVersion.
     */
    public String getSoapVersion() {
        return soapVersion;
    }
    /**
     * @param soapVersion The soapVersion to set.
     */
    public void setSoapVersion(String soapVersion) {
        this.soapVersion = soapVersion;
    }
    /**
     * @return Returns the urn.
     */
    public String getUrn() {
        return urn;
    }
    /**
     * @param urn The urn to set.
     */
    public void setUrn(String urn) {
        this.urn = urn;
    }
}
