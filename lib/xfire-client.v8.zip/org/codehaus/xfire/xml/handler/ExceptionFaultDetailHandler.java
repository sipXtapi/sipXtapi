package org.codehaus.xfire.xml.handler;

import org.codehaus.xfire.MessageContext;
import org.codehaus.xfire.fault.XFireFault;
import org.codehaus.xfire.handler.AbstractHandler;
import org.codehaus.xfire.handler.Handler;
import org.codehaus.yom.Element;
import org.codehaus.yom.Text;

/**
 * Handler which adds on fault the exception class name as detail in the fault body
 */
public class ExceptionFaultDetailHandler extends AbstractHandler implements Handler {

    /**
     * @see org.codehaus.xfire.handler.Handler#invoke(org.codehaus.xfire.MessageContext)
     */
    public void invoke(MessageContext context) throws Exception {
        // do nothing
    }

    /**
     * append detail to soap fault body with exception classname
     *  
     * @see org.codehaus.xfire.handler.Handler#handleFault(org.codehaus.xfire.fault.XFireFault, org.codehaus.xfire.MessageContext)
     */
    public void handleFault(XFireFault fault, MessageContext context) {
        if(fault.getCause()!=null){
          // create detail if necessary  
          if(fault.getDetail()==null){
              fault.setDetail(new Element("detail"));              
          }
          Element exceptionElement = new Element("exception");
          exceptionElement.appendChild(new Text(fault.getCause().getClass().getName()));
          fault.getDetail().appendChild(exceptionElement);            
        }
    }

}
